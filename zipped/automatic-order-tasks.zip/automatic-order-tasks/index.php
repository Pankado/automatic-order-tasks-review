<?php 
/* Silence is golden */
?>